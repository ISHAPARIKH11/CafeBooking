@extends('master')
@section('main-content')
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Document</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>

    <body>
        <div>
            <form action="{{ url('/cafe') }}" method="post">
                @csrf
                <div class="form-group">
                    <label>Customer Name</label>
                    <input type="text" class="form-control" name="customer_name" placeholder="Enter Customer Name">
                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Mobile No</label>
                        <input type="text" class="form-control" name="mobile_no" placeholder="Enter mobile no">
                    </div>

                    <div class="form-group col-md-6">
                        <label>Email</label>
                        <input type="text" class="form-control" name="email" placeholder="Enter Email">
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Computer No</label>
                        <input type="text" class="form-control" name="computerno" placeholder="Enter computer no">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Amount</label>
                        <input type="text" class="form-control" name="amount" placeholder="Enter Amount">
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>In Time</label>
                            <input type="text" class="form-control" name="intime" placeholder="Enter In Time">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Out Time</label>
                            <input type="text" class="form-control" name="outtime" placeholder="Enter Out Time">
                        </div>
                    </div>
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
        @if (session()->get('message'))
            <table class="table">
                <div class="table" style="text-align: center;">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">Cafe ID</th>
                            <th scope="col">Customer Name</th>
                            <th scope="col">Mobile No</th>
                            <th scope="col">Email</th>
                            <th scope="col">Computer No</th>
                            <th scope="col">Amount</th>
                            <th scope="col">Intime</th>
                            <th scope="col">Outtime</th>
                            <th scope="col">Total Usage Time</th>
                            <th scope="col">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($cafe as $c)
                            <tr>
                                <td>{{ $c->cafeid }}</td>
                                <td>{{ $c->customer_name }}</td>
                                <td>{{ $c->mobile_no }}</td>
                                <td>{{ $c->email }}</td>
                                <td>{{ $c->computerno }}</td>
                                <td>{{ $c->amount }}</td>
                                <td>{{ $c->intime }}</td>
                                <td>{{ $c->outtime }}</td>
                                <td>{{ $c->outtime - $c->intime }}</td>
                                <td>
                                    <a href="{{ route('cafe.destroy', ['id' => $c->cafeid]) }}">
                                        <button class="btn btn-danger">Delete</button>
                                    </a>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </div>
            </table>
        @endif
    </body>

    </html>
@endsection
