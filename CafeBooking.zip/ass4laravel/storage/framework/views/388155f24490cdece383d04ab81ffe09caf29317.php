<?php $__env->startSection('main-content'); ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Document</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
            integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>

    <body>
        <div>
            <form action="<?php echo e(url('/cafe')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Customer Name</label>
                    <input type="text" class="form-control" name="customer_name" placeholder="Enter Customer Name">
                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Mobile No</label>
                        <input type="text" class="form-control" name="mobile_no" placeholder="Enter mobile no">
                    </div>

                    <div class="form-group col-md-6">
                        <label>Email</label>
                        <input type="text" class="form-control" name="email" placeholder="Enter Email">
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-6">
                        <label>Computer No</label>
                        <input type="text" class="form-control" name="computerno" placeholder="Enter computer no">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Amount</label>
                        <input type="text" class="form-control" name="amount" placeholder="Enter Amount">
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>In Time</label>
                            <input type="text" class="form-control" name="intime" placeholder="Enter In Time">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Out Time</label>
                            <input type="text" class="form-control" name="outtime" placeholder="Enter Out Time">
                        </div>
                    </div>
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
        <?php if(session()->get('message')): ?>
            <table class="table">
                <div class="table" style="text-align: center;">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">Cafe ID</th>
                            <th scope="col">Customer Name</th>
                            <th scope="col">Mobile No</th>
                            <th scope="col">Email</th>
                            <th scope="col">Computer No</th>
                            <th scope="col">Amount</th>
                            <th scope="col">Intime</th>
                            <th scope="col">Outtime</th>
                            <th scope="col">Total Usage Time</th>
                            <th scope="col">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cafe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($c->cafeid); ?></td>
                                <td><?php echo e($c->customer_name); ?></td>
                                <td><?php echo e($c->mobile_no); ?></td>
                                <td><?php echo e($c->email); ?></td>
                                <td><?php echo e($c->computerno); ?></td>
                                <td><?php echo e($c->amount); ?></td>
                                <td><?php echo e($c->intime); ?></td>
                                <td><?php echo e($c->outtime); ?></td>
                                <td><?php echo e($c->outtime - $c->intime); ?></td>
                                <td>
                                    <a href="<?php echo e(route('cafe.destroy', ['id' => $c->cafeid])); ?>">
                                        <button class="btn btn-danger">Delete</button>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </div>
            </table>
        <?php endif; ?>
    </body>

    </html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ass4laravel\resources\views/booking.blade.php ENDPATH**/ ?>