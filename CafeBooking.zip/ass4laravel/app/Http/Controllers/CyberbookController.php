<?php

namespace App\Http\Controllers;

use App\Models\Cafe;
use Illuminate\Http\Request;
use Session;

class CyberbookController extends Controller
{
    public function data(Request $request)
    {
        $cafe = new Cafe;
        $cafe = Cafe::all();
        $data = compact('cafe');
        return view('booking')->with($data);
    }
    public function insert(Request $request)
    {
        $cafe = new Cafe;
        $cafe->customer_name = $request['customer_name'];
        $cafe->mobile_no = $request['mobile_no'];
        $cafe->email = $request['email'];
        $cafe->computerno = $request['computerno'];
        $cafe->amount = $request['amount'];
        $cafe->intime = $request['intime'];
        $cafe->outtime = $request['outtime'];
        $cafe->save();
        return redirect('/cafe')->with('message', "Inserted");
    }
    public function destroy($id)
    {
        $user = Cafe::find($id);
        if (!is_null($user)) {
            $user->delete();
        }
        return view('booking');
    }
}
